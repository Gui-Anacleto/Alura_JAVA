
public class TestePontoFlutuante {
	public static void main(String[] args) {
		double salario;
		salario = 1250.70;
		System.out.println("Meu salario é "+ salario);
		
		//double idade = 37;
		
		double divisao = 3.14/2;
		
		System.out.println(divisao);
		
		int outraDivisao = 5/2;
		
		System.out.println(outraDivisao);
		
		double novaTentativa = 5.0/2;
		
		System.out.println(novaTentativa);
		
	}
}

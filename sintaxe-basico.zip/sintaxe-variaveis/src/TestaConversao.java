
public class TestaConversao {
	public static void main(String[] args) {
		double salario = 1270.50;
		int valor = (int)salario; //casting
		System.out.println(valor);
	
		
	}
}

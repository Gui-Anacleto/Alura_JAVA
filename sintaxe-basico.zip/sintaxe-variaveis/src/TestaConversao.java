
public class TestaConversao {
	public static void main(String[] args) {
		double salario = 1270.50;
		
		//float pontoFlutuante = 3.14f;
		
		int valor = (int)salario; //casting
		System.out.println(valor); // 1270
	
		//long numeroGrande = 321321231L; //ex
		
		double valor1 = 0.2;
		double valor2 = 0.1;
		double total = valor1 + valor2;
		
		System.out.println(total);// 0.30000000000000004

	}
}


public class TesteVariaveis {
	public static void main(String[] args) {
		System.out.println("Hello world!");
	
		int idade;
		idade = 22;
		
		System.out.println(idade);
		
		idade = 30 + 10;
		idade = (7*5)+2;
		
		System.out.println(idade);
		System.out.print(idade);//sem pular linha
		System.out.println("A idade é "+ idade +"parabéns.");
		
	}
}

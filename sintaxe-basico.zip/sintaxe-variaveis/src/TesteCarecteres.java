
public class TesteCarecteres {
	public static void main(String[] args) {
		char letra = 'a';
		System.out.println(letra);
		
		char valor = 65;
		System.out.println(valor);
		
		valor = (char)(valor+1);
		System.out.println(valor);
		
		String palavra = "Alura cursos online ";
		System.out.println(palavra);
		
		palavra = palavra+2022;
		
		System.out.println(palavra);
	}
}
